import { expect, it } from "vitest";
import { PieceType, applyMove, createInitialState, legalMoves } from "@li4chess/engine";
import { positionHash, searchSignature, TranspositionTable, updatePositionHash } from "../src/hash.js";
import { loadPosition, positions } from "../src/positions.js";
import { searchPosition } from "../src/lab-search.js";

it("distinguishes native and pawn-Queens in full and incremental hashes", () => {
  const before = createInitialState();
  const board = before.board.slice();
  board[6] = { ...board[6]!, promotedFrom:PieceType.Pawn };
  const after = { ...before, board };
  expect(positionHash(after)).not.toBe(positionHash(before));
  expect(searchSignature(after)).not.toBe(searchSignature(before));
  expect(updatePositionHash(positionHash(before), before, after)).toBe(positionHash(after));
});

it("retains award history and logical event sequence in search identity", () => {
  const before = createInitialState();
  for (const after of [{ ...before,eventSequence:1 }, { ...before,awardLedger:[
    { sequence:2,causeSequence:1,rule:"capture" as const,recipient:0 as const,delta:1,total:1 },
  ] }]) {
    expect(positionHash(after)).not.toBe(positionHash(before));
    expect(searchSignature(after)).not.toBe(searchSignature(before));
    expect(updatePositionHash(positionHash(before),before,after)).toBe(positionHash(after));
  }
});

it("delta hashes match full recomputation over legal paths and tactical transitions", () => {
  for (const spec of positions) {
    let state = loadPosition(spec); let hash = positionHash(state);
    for (let ply=0;ply<8 && !state.result;ply++) {
      const moves=legalMoves(state); const child=applyMove(state,moves[(ply*7)%moves.length]);
      hash=updatePositionHash(hash,state,child); expect(hash).toBe(positionHash(child)); state=child;
    }
  }
});
it("separates histories, scores, moved flags, statuses and rejects collisions", () => {
  const state=createInitialState(); const hash=positionHash(state);
  const changes=[{...state,turn:1 as const},{...state,positionCounts:{}},{...state,enPassantRights:[{target:34,pawnSquare:48,pawnOwner:0 as const,eligiblePlayers:[2 as const]}]},
    {...state,players:{...state.players,0:{...state.players[0],score:1}}},
    {...state,board:state.board.map((p,i)=>i===3 && p ? {...p,hasMoved:true}:p)}];
  for (const changed of changes) expect(positionHash(changed)).not.toBe(hash);
  const tt=new TranspositionTable(1);
  tt.set(hash,{signature:searchSignature(state),depth:1,value:3,bound:"exact"});
  expect(tt.get(hash,"different")).toBeUndefined();
  tt.set(1n,{signature:"second",depth:1,value:1,bound:"upper"});
  expect(tt.get(hash,searchSignature(state))).toBeUndefined();
});
it("TT preserves fixed-depth values", () => {
  const state=loadPosition(positions.find(p=>p.id==="king-endgame")!);
  const a=searchPosition(state,{maxDepth:3}),b=searchPosition(state,{maxDepth:3,ttCapacity:1000});
  expect(a.value).toBe(b.value); expect(a.move).toEqual(b.move);
});
it("hash deltas include castling, en passant removal, promotion and cascading elimination", () => {
  const base=createInitialState();const board=base.board.slice();board[8]=null;board[9]=null;
  const castle={...base,board};
  const castleMove=legalMoves(castle).find(m=>m.castle==="kingside")!;
  expect(castleMove).toBeDefined();
  const epBase=loadPosition({id:"ep",tags:[],inactive:[1,3],pieces:[[7,0,"K"],[188,2,"K"],[20,0,"P"],[47,2,"P"]]});
  const epBoard=epBase.board.slice(); epBoard[20]={...epBoard[20]!,hasMoved:false};
  const epStart={...epBase,board:epBoard};
  const push=legalMoves(epStart).find(m=>m.from===20 && m.to===48)!;
  const epState=applyMove(epStart,push);
  const ep=legalMoves(epState).find(m=>m.enPassantCapture===48)!;expect(ep).toBeDefined();
  const promotion=loadPosition(positions.find(p=>p.id==="promotion")!);
  const mate=loadPosition(positions.find(p=>p.id==="mate-in-one")!);
  for (const [state,move] of [[castle,castleMove],[epState,ep],[promotion,legalMoves(promotion).find(m=>m.promotion)!],
    [mate,legalMoves(mate).find(m=>m.from===73 && m.to===3)!]] as const) {
    const child=applyMove(state,move);expect(updatePositionHash(positionHash(state),state,child)).toBe(positionHash(child));
  }
});

it("FFA-DRAW-09: draw counter changes search identity and incremental hash",()=>{
  const before=createInitialState(),after={ ...before,reversibleMoves:199 };
  expect(positionHash(before)).not.toBe(positionHash(after));
  expect(searchSignature(before)).not.toBe(searchSignature(after));
  expect(updatePositionHash(positionHash(before),before,after)).toBe(positionHash(after));
});

it("hashes and signatures distinguish all en-passant rights and per-player eligibility", () => {
  const state=createInitialState();
  const right={target:34,pawnSquare:48,pawnOwner:0 as const,eligiblePlayers:[1 as const,2 as const]};
  const before={...state,enPassantRights:[right]};
  for (const enPassantRights of [[],[{...right,eligiblePlayers:[2 as const]}],
    [{...right,pawnSquare:49}],[{...right,target:35}],[{...right,pawnOwner:3 as const}],
    [right,{target:72,pawnSquare:73,pawnOwner:1 as const,eligiblePlayers:[0 as const]}]]) {
    const after={...before,enPassantRights};
    expect(positionHash(after)).not.toBe(positionHash(before));
    expect(searchSignature(after)).not.toBe(searchSignature(before));
    expect(updatePositionHash(positionHash(before),before,after)).toBe(positionHash(after));
  }
});
